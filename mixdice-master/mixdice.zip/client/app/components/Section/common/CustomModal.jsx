import React from "react";
import { Modal, ModalHeader, ModalBody, ModalFooter } from 'reactstrap';
import NavbarBrand from "../Header/NavbarBrand";
import CustomTab from "./CustomTab";

class CustomModal extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
          modal: true,
          centered: true,
          backdrop: "static"
        };
    
        this.toggle = this.toggle.bind(this);
    }
    
    toggle() {
        this.setState(prevState => ({
            modal: !prevState.modal
        }));
    }
    
    render() {
        return (
            <div>
                <Modal isOpen={this.state.modal} centered={this.state.centered} fade={false} toggle={this.toggle} className={this.props.className} backdrop={this.state.backdrop}>
                    <ModalHeader>
                        <NavbarBrand />
                    </ModalHeader>
                    <ModalBody>
                        <CustomTab />
                    </ModalBody>
                    <ModalFooter></ModalFooter>
                </Modal>
            </div>
        );
    }
}

export default CustomModal;
