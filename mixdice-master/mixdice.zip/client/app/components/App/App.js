import React, { Component } from "react";

import Header from "../Header/Header";
import CustomModal from "../Section/CustomModal";
import Footer from "../Footer/Footer";

const App = ({ children }) => (
  <>
    <Header />
    <CustomModal className="custom-modal" />
    <main>{children}</main>
  </>
);

export default App;
