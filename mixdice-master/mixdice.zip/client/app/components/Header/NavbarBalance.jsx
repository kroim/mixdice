import React from "react";
import PropTypes from "prop-types";
import classNames from "classnames";
import {
  DropdownToggle,
  NavItem,
  DropdownMenu,
  DropdownItem,
  UncontrolledDropdown,
  Nav
} from "reactstrap";
import Eth from "../../../public/assets/svg/crypto/eth.svg";
import Ltc from "../../../public/assets/svg/crypto/ltc.svg";
import Neo from "../../../public/assets/svg/crypto/neo.svg";
import Xrp from "../../../public/assets/svg/crypto/xrp.svg";
const data = [
  {key: '1', icon: Eth, amount: '0.00000546'},
  {key: '2', icon: Ltc, amount: '0.00043654'},
  {key: '3', icon: Neo, amount: '0.00000054'},
  {key: '4', icon: Xrp, amount: '0.00000023'},
];
const NavbarBalance = () => (
  <Nav className="ml-auto mr-auto">
    <UncontrolledDropdown nav inNavbar>
      <DropdownToggle nav caret>
        <img src="/assets/img/bitcoin.png" className={classNames("mr-3")} />
        0.00035660
      </DropdownToggle>
      <DropdownMenu
        className={classNames("nav__dropdown-balance__container")}
        right
      >
        <div className={classNames("nav__dropdown-balance")}>
          {data.map(({icon: Icon, ...e, }) => <DropdownItem key={e.key}><Icon/>{e.amount}</DropdownItem>)}
        </div>
      </DropdownMenu>
    </UncontrolledDropdown>
  </Nav>
);
export default NavbarBalance;
