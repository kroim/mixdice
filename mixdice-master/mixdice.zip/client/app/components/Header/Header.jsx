import React from "react";
import NavbarBrand from "./NavbarBrand.jsx";
import NavbarContent from "./NavbarContent.jsx";
import { Collapse, Navbar } from "reactstrap";
import NavbarBalance from "./NavbarBalance";
import NavbarToggle from "./NavbarToggle";
import classNames from "classnames";
import NavbarProfileDropdownMenu from "./NavbarProfileDropdownMenu";

class Header extends React.Component {
  state = {
    isOpen: false
  };

  toggle = () =>
    this.setState({
      isOpen: !this.state.isOpen
    });

  render() {
    const { isOpen } = this.state;
    return (
      <Navbar light expand="md">
        <NavbarBrand isFullLogo={isOpen} />
        <NavbarBalance />
        <NavbarToggle navExpanded={isOpen} onClick={this.toggle} />
        <Collapse isOpen={isOpen} navbar>
          <NavbarContent className={classNames("navbar__content-collapse")} />
          <NavbarProfileDropdownMenu
            className={classNames("navbar__content-collapse-visible")}
          />
        </Collapse>
      </Navbar>
    );
  }
}

export default Header;
