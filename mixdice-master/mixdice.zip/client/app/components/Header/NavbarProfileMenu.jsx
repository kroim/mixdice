import React from "react";
import { DropdownToggle, UncontrolledDropdown } from "reactstrap";
import Avatar from "../../../public/assets/svg/avatar.svg";
import NavbarProfileDropdownMenu from "./NavbarProfileDropdownMenu";
const ProfileAvatar = () => <Avatar />;

export default () => (
  <UncontrolledDropdown nav inNavbar>
    <DropdownToggle nav caret>
      <ProfileAvatar /> email@gmail.com
    </DropdownToggle>
    <NavbarProfileDropdownMenu />
  </UncontrolledDropdown>
);
