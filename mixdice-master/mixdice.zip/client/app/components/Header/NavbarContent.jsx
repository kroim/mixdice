import React from "react";
import NavbarProfileMenu from "./NavbarProfileMenu";
import Wallet from "../../../public/assets/svg/wallet.svg";
import Withdraw from "../../../public/assets/svg/withdraw.svg";
import classNames from "classnames";

import { Button, Nav, NavItem } from "reactstrap";

export default props => (
  <>
    <Nav {...props} navbar className={classNames("ml-auto", props.className)}>
      <NavItem>
        <Button color="primary">
          <Wallet />
          Deposit
        </Button>
      </NavItem>
      <NavItem>
        <Button color="primary">
          <Withdraw />
          Withdraw
        </Button>
      </NavItem>
      <NavbarProfileMenu />
    </Nav>
  </>
);
